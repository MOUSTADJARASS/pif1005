import java.util.Scanner;
import java.util.ArrayList;
public class Main {
    private static Graphe newGraphe;
    public static void main(String[] args) {
        Menu();
    }

    private static void Options() {
        System.out.println("\t\t\t veuiller faire votre choix :\n");
        System.out.println("1 - pour cree un graphe.\n");
        System.out.println("2 - pour afficher les caracteristique du graphe.\n");
        System.out.println("");
    }

    private static int Valide(int a, int b) {
        Scanner scan = new Scanner(System.in);
        int x = scan.nextInt();
        while (x > b || x < a) {
            System.out.println("le chiffre que vous avez entré sont incorrecte ");
            System.out.println("veuillez entrer un chiffre entre " + a + " et " + b);
            x = scan.nextInt();
        }
        return x;
    }

    private static void Menu() {
        Options();
        int choix = Valide(1, 3);

        switch (choix) {
            case 1:

              cree();
                break;
            case 2:
                if(newGraphe!=null){

                }else{
                    System.out.println("-----vous n'avez pas encore cree de graphes -----");
                    Menu();
                }
               break;
        }
    }

    private static void cree() {

        System.out.println("veuillez entrer le nombres de sommet du graphe :");

        int nombre = Valide(1, 1000);
       newGraphe = new Graphe(nombre);
        creeArc(newGraphe,nombre);
    }

    private static void creeArc(Graphe graphe, int nombre) {

        int choix = 0;
        while (choix != 2) {
            System.out.println("/n veuillez entrer votre choix :");
            System.out.println("1- creer un arc :");
            System.out.println("2- terminé!!! :");
            choix = Valide(1, 2);
            if (choix == 1) {
                System.out.print("veuiller entrer le premier sommet (sommet 1 ou 2 ou 3 par exemple) : ");
                int sommet1 = Valide(1, nombre);
                System.out.print("veuiller entrer le deuxieme sommet (sommet 1 ou 2 ou 3 par exemple) : ");
                int sommet2 = Valide(1, nombre);
                graphe.AjouterArc(sommet1-1, sommet2-1);
                graphe.afficher();
            } else{
               int[][] adj = matriceAdjacence(nombre);
                matriceIncidence(newGraphe.getCouple());
                break;}
        }
    }
    private static int[][] matriceAdjacence(int a){
        int[][] Adjacence = new int[a][a];
            System.out.println("\t\t\t"+ "Matrice d'adjacencen\n");

        for(int i =0;i < a;i++) {
            for (int j = 0; j < a; j++) {
                if (newGraphe.getGraphe().get(i).contains(j)) {
                    Adjacence[i][j] = 1;
                    Adjacence[j][i] = 1;

                }
            }
        }
        for (int i = 0; i < a; i++) {
            System.out.print("\n" + (i + 1));
            for (int j = 0; j < a; j++) {
                System.out.print("\t\t" + Adjacence[i][j]);
            }
        }
         return Adjacence;
    }

    private static void matriceIncidence(ArrayList<ArrayList<Integer>> adj)
        {
            int a =0;
            int b =0;
            int vertices = newGraphe.getSommet(), edges = 0;


        int[][] Incidence = new int[newGraphe.getSommet()][newGraphe.getCouple().size()];
            System.out.println();
                System.out.println("\nMatrice d'Incidence");
                for (int i=0;i<newGraphe.getCouple().size() ;i++ ){
                    a = newGraphe.getCouple().get(i).get(0);
                    b = newGraphe.getCouple().get(i).get(1);
                System.out.print("\t\t"+((a+1)+","+(b+1)));

                    Incidence[a][i]= 1;
                    Incidence[b][i]= 1;
           /* for(int i=0; i<newGraphe.getCouple().size();i++ ){
                for(int k=0; k< newGraphe.getSommet();k++ ) {
                    if ( k == newGraphe.getCouple().get(i).get(0) || k == newGraphe.getCouple().get(i).get(1)) {
                        Incidence[k][j] = 1;
                        break;
                    }
                }*/
            }

            for (int i = 0; i < newGraphe.getSommet(); i++) {
                System.out.print("\n" + (i + 1));
                for (int j = 0; j < newGraphe.getCouple().size(); j++) {
                    System.out.print("\t\t" + Incidence[i][j]);
                }
            }
    }

}







