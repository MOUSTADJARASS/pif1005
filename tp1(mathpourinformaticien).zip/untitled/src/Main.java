import java.util.Scanner;
import java.util.ArrayList;
public class Main {
    private static Graphe newGraphe;
    public static void main(String[] args) {
        Menu();
    }

    private static void Options() {
        System.out.println("\t\t\t veuiller faire votre choix :\n");
        System.out.println("1 - pour cree un graphe.\n");
        System.out.println("2 - pour afficher les matrice d'incidence et d'adjacence \n");
        System.out.println("3 - pour afficher les caracteristique du graphe.\n");
        System.out.println("");
    }

    private static int Valide(int a, int b) {
        Scanner scan = new Scanner(System.in);
        int x = scan.nextInt();
        while (x > b || x < a) {
            System.out.println("le chiffre que vous avez entré sont incorrecte ");
            System.out.println("veuillez entrer un chiffre entre " + a + " et " + b);
            x = scan.nextInt();
        }
        return x;
    }

    private static void Menu() {
        Options();
        int choix = Valide(1, 3);

        switch (choix) {
            case 1:

              cree();
                break;
            case 2:
               break;
        }
    }

    private static void cree() {

        System.out.println("veuillez entrer le nombres de sommet du graphe :");

        int nombre = Valide(1, 1000);
       newGraphe = new Graphe(nombre);
        creeArc(newGraphe,nombre);
    }

    private static void creeArc(Graphe graphe, int nombre) {

        int choix = 0;
        while (choix != 2) {
            System.out.println("/n veuillez entrer votre choix :");
            System.out.println("1- creer un arc :");
            System.out.println("2- terminé!!! :");
            choix = Valide(1, 2);
            if (choix == 1) {
                System.out.print("veuiller entrer le premier sommet (sommet 1 ou 2 ou 3 par exemple) : ");
                int sommet1 = Valide(1, nombre);
                System.out.print("veuiller entrer le deuxieme sommet (sommet 1 ou 2 ou 3 par exemple) : ");
                int sommet2 = Valide(1, nombre);
                graphe.AjouterArc(sommet1-1, sommet2-1);
                graphe.afficher();
            } else{
               int[][] adj = matriceAdjacence(nombre);
                matriceIncidence(adj);
                break;}
        }
    }
    private static int[][] matriceAdjacence(int a){
        int[][] Adjacence = new int[a][a];
            System.out.println("\t\t\t"+ "Matrice d'adjacencen\n");

        for (int t =0;t<a;t++){

            System.out.print("\t\t"+(t+1));
        }
            System.out.println();
        for(int i =0;i < a;i++) {
            for (int j = 0; j < a; j++) {
                if (newGraphe.Graphe.get(i).contains(j)) {
                    Adjacence[i][j] = 1;
                } else {

                    Adjacence[i][j] = 0;
                }
            }
        }
        for (int i = 0; i < a; i++) {
            System.out.print("\n" + (i + 1));
            for (int j = 0; j < a; j++) {
                System.out.print("\t\t" + Adjacence[i][j]);
            }
        }
         return Adjacence;
    }

    private static void matriceIncidence(int[][] adj)
        {
            int vertices = adj.length, edges = 0;

            // count number of edges in the graph
            for (int i = 0; i < adj.length; i++) {
                for (int j = i + 1; j < adj[i].length; j++) {
                    if (adj[i][j] > 0)
                        edges++;
                }
            }

            // construct incidence matrix
            int[][] incidenceMat = new int[adj.length][edges];
            for (int i = 0; i < adj.length; i++) {

                for (int j = i + 1; j < adj[i].length; j++) {
                    int edgeNumber = adj[i][j];

                    if (edgeNumber > 0) {
                        incidenceMat[i][edgeNumber - 1] = 1;
                        incidenceMat[j][edgeNumber - 1] = 1;
                    }
                }

            }
            for (int[] row : incidenceMat) {
                for (int val : row) {
                    System.out.print(val);
                }
                System.out.println();
            }
    }

}







