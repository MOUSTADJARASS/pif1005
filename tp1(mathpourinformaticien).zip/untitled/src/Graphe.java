import java.util.ArrayList;

public class Graphe {
    ArrayList<ArrayList<Integer>> Graphe;
    private int sommet ;
    public Graphe(int sommet){
        this.sommet = sommet;
        Graphe= new ArrayList<ArrayList<Integer>>();
        for(int i=0;i<sommet;i++ ){
            Graphe.add(new ArrayList<Integer>());
        }
    }
    void AjouterArc(int a,int b){
        Graphe.get(a).add(b);
        Graphe.get(b).add(a);
    }
    void afficher(){
        for (int i =0;i<sommet;i++){
           int index1 = i +1;
            System.out.print("noeud "+(i+1)+" :" );
            for (int x: Graphe.get(i)){
                System.out.print("->"+ (x+1));
            }
                System.out.println();
        }
    }
    public int getSommet(){
        return sommet;
    }
}
